import { Router } from "express";
import { methods as deleteuserController } from "./../controllers/deleteuser.controllers";

const router = Router();

router.post("/", deleteuserController.deleteUser);




export default router; 