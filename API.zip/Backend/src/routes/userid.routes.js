import { Router } from "express";
import { methods as userbyid } from "./../controllers/userid.controllers";

const router = Router();

router.get("/",userbyid.getbyid );
router.post("/",userbyid.modifyUser);




export default router;