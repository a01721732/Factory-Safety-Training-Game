import { Router } from "express";
import {methods as gamedataController} from "./../controllers/gamedata.controllers";


const router = Router();

router.get("/", gamedataController.gamedata);
router.post("/", gamedataController.recivegamedata);


export default router;