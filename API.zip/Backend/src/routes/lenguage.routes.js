import { Router } from "express";
import {methods as lenguageController} from "./../controllers/lenguage.controllers";


const router = Router();

router.get("/", lenguageController.getLenguages);
router.post("/", lenguageController.addLenguage);


export default router;