import express from "express";
import morgan from "morgan";
//routes
import lenguageRoutes from "./routes/lenguage.routes";
import userRoutes from "./routes/user.routes";
import userbyidRoutes from "./routes/userid.routes";
import deleteuserRoutes from "./routes/deleteuser.routes";
import gamedata from "./routes/gamedata.routes";

const app = express(); // create express app 

// settings

app.set("port", 4000); // set port

// middlewares
app.use(morgan("dev"));
app.use(express.json()); // to understand json format
app.use(express.text())
app.use(express.urlencoded({ extended: true }))

// routes 
app.use("/api/lenguages" , lenguageRoutes)
app.use("/api/user" , userRoutes)
app.use("/api/modify", userbyidRoutes)
app.use("/api/delete", deleteuserRoutes )
app.use("/api/gamedata", gamedata)



//cors  
var cors = require('cors')


app.use(cors())

export default app;