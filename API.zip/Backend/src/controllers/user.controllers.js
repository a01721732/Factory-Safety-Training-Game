import { json } from "express";
import { getConnection } from "./../database/database";

const getUsers = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    try {
        const connection = await getConnection();
        const result = await connection.query("SELECT * FROM `user`");


        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message)
    }
}

const addUser = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Methods', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Headers', 'http://localhost:4200');



    const { id, name, password, email, gender, role, isactive } = JSON.parse(req.body);

    const newUser = {
        id, name, password, email, gender, role, isactive
    }

    const connection = await getConnection();

    const result = await connection.query("INSERT INTO `user` SET ?", newUser)

    res.json(result);
}

    const modifyUser = async (req, res) => {

        


        console.log(req.body);

        const { id, name, password, email, gender, role, isactive } = JSON.parse(req.body);

        const newUser = {
            id, name, password, email, gender, role, isactive
        }

        console.log(req.body);
        console.log(newUser);

        const connection = await getConnection();


        //const result = await connection.query("UPDATE `user` SET `name` = ?, `password` = ?, `email` = ?, `gender` = ?, `role` = ?, `isactive` = ? WHERE `id` = ?",
        // [newUser.name, newUser.password, newUser.email, newUser.gender, newUser.role, newUser.isactive, newUser.id]);

        res.json(result);
    }






export const methods = {
    modifyUser,
    getUsers,
    addUser,
}

