
import { getConnection } from './../database/database';

const getLenguages = async (req, res) => {


    try {
        const connection = await getConnection();
        const result = await connection.query("SELECT id, name, programers FROM lenguage");
        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message)
    }
}

const addLenguage = async (req, res) => {


    try {
        const { name, programers } = req.body;

        if(name ===undefined || programers === undefined){
            res.status(400).json({message:"BadRequest"})
        }

        const lenguage = {
            name, programers
        }

        const connection = await getConnection();

        const result = await connection.query("INSERT INTO lenguage SET ?", lenguage)

        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message)
    }
}

export const methods = {
    getLenguages,
    addLenguage
}; 
