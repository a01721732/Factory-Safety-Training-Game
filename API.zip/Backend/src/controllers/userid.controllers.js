import { getConnection } from "./../database/database";

const getbyid = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    try {
        const connection = await getConnection();
        const result = await connection.query("SELECT * FROM `user`");

        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message)
    }
}

const modifyUser = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Methods', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Headers', 'http://localhost:4200');


    const { id, name, password, email, gender, role, isactive } = JSON.parse(req.body);

    const newUser = {
        id, name, password, email, gender, role, isactive
    }


    const connection = await getConnection();


    const result = await connection.query("UPDATE `user` SET `name` = ?, `password` = ?, `email` = ?, `gender` = ?, `role` = ?, `isactive` = ? WHERE `id` = ?",
    [newUser.name, newUser.password, newUser.email, newUser.gender, newUser.role, newUser.isactive, newUser.id]);

    res.json(result);
}

export const methods = {
    getbyid,
    modifyUser
}