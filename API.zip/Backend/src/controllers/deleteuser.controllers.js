import { json } from "express";
import { getConnection } from "./../database/database";

const deleteUser = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Methods', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Headers', 'http://localhost:4200');



    const { id, name, password, email, gender, role, isactive } = JSON.parse(req.body);

    const newUser = {
        id, name, password, email, gender, role, isactive
    }

    console.log(newUser);
    console.log(id);
    const connection = await getConnection();

    const result = await connection.query("DELETE FROM `user` where id = ?", id)

    res.json(result);
}







export const methods = {
    deleteUser
}

