import { json } from "express";
import { getConnection } from "./../database/database";

const gamedata = async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    try {
        const connection = await getConnection();
        const result = await connection.query("SELECT user.id, user.name, gamematch.Score, gamematch.UsedTimeMatch from user, gamematch WHERE user.id = gamematch.UserID;");


        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message)
    }
}

const recivegamedata = async (req, res) => {

    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Methods', 'http://localhost:4200');
    res.setHeader('Access-Control-Allow-Headers', 'http://localhost:4200');



    console.log(req.body);


}

export const methods = {
    gamedata,
    recivegamedata
}